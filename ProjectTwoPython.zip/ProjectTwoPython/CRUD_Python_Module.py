#Creat/r Daktoa Osborne
#Date: 08/02/2026
#This program completes CRUD operations to a MongoDB database
    
from pymongo import MongoClient 
import pymongo
from pymongo.errors import PyMongoError
from bson.objectid import ObjectId 

class AnimalShelter(object): #object parameter is deleted
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, userName, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        #USER = 'aacuser' 
        USER = userName
        #PASS = 'Viper7' 
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 
        

    # Create a method to return the next available record number for use in the create method
            
    # This method inserts a document into the database
    def create(self, data):
        try: 
            #if the dictionary is not empty 
            if bool(data): 
                #Insert data dictionary
                self.database.animals.insert_one(data)  # data should be dictionary 
                print("Returned true")
                return True
                    
                   
            # if the data is empty throw exception
            else: 
                return False
                #raise Exception("Nothing to save, because data parameter is empty") 
        #except pymongo.errors.WriteError(error, code=None, details=None, max_wire_version=None):
        except PyMongoError as error:
           
            return False

    #This method reads documents in the database
    #Parameter 1: query attibute --- String
    #Parameter 2: query value --- String
    
    def read(self, attribute, value):
        try:
            #if any of the parameters are empty raise excpetion
            if(attribute is None or value is None):
                raise Exception("Parameters are empty")
            #else find all documents and return the a list of them
            #if there are no documents it returns a empty list
            else:
                print("Find")
                #query
                findAll = self.database.animals.find({attribute: value})
                returnList = []
                #for every document found in the query add to the list
                for doc in findAll:
                    returnList.append(doc)
                    
               
                return returnList
                
            
        #except pymongo.errors.OperationFailure(error, code=None, details=None, max_wire_version=None):
        except PyMongoError as error:
            print("Operation failed")
            

    
    
    #This method queries the databse with a dictionary instead of a single key/value pair
    #Parameter 1: query --- Dicitonary
    def read2(self, query):
        try:
            #if dictionary is not empty
           # if bool(query):
                   # print("Find")
                    #query the database with the query dictionary 
            findAll = self.database.animals.find(query)
            returnList = []
                    #for every document found in the query add to the list
            for doc in findAll:
                returnList.append(doc)
                    
            return returnList

           # else:
              #  raise excepetion("emtpy dictionary")
        #except pymongo.errors.OperationFailure(error, code=None, details=None, max_wire_version=None):
        except PyMongoError as error:
            print("Operation failed")
                    
                    
                    
                    
    #This method removes documents from the database
    #Parameter 1: query attibute --- String
    #Parameter 2: query value --- String
    def remove(self, attribute, value):
        try:
            #if the parameters are empty throw exception
            if(attribute is None or value is None):
                
                raise exception("Empty parameters")
            else:
                print("remove")
                #query parameter
                query = {attribute: value}
                #deleted documents from the database
                deleted = self.database.animals.delete_many(query)
                #return the number of deleted documents
                return deleted.deleted_count
            
        #except pymongo.errors.OperationFailure(error, code=None, details=None, max_wire_version=None):
        except PyMongoError as error:
            print("Operation failed")
            
            
    #This method updates documents in the databse
    #Parameter 1: query attibute --- String
    #Parameter 2: query value --- String
    #Parameter 3: attibute that will be updated --- String
    #Parameter 4: value that will be updated --- String
    def update(self, attribute, value, updateAttribute, updateValue):
        try:
            #if any of the parameters are empty throw excpetion
            if(attribute is None or value is None or updateAttribute is None or updateValue is None):
                raise Exception("Empty parameters")
            else:
                print("update")
                #query parameter for the update method
                query = {attribute: value}
                #what will be changed/ update parameters
                updateParam = {'$set': {updateAttribute: updateValue}}
                #update the document
                updated = self.database.animals.update_many(query, updateParam)
                #return how many documents were modified
                return updated.modified_count
                
        #except pymongo.errors.OperationFailure(error, code=None, details=None, max_wire_version=None):
        except PyMongoError as error:
            print("Operation failed")
